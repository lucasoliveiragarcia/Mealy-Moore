/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealymoore;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Mealy {
    private List <String> inputSymbolsMly;
    private List <String> outputSymbolsMly;
    private List <String> statesSetMly;
    private String startMly;
    private List <String> finalMly;
    private List <ArrayList <String>> transSetMly;

    public Mealy() {
    }
    
    
    
    public Mealy(List <String> mealyMaq) 
    {
        this.inputSymbolsMly=new ArrayList<>();
        this.outputSymbolsMly=new ArrayList<>();
        this.statesSetMly=new ArrayList<>();
        this.startMly="";
        this.finalMly=new ArrayList<>();
        this.transSetMly=new ArrayList<>();
        String [] wordSeq = null;
        //String [] transSet = new String[4];
        int si=0,so=0,st=0,sta=0,sf=0,tr=0;
        List <String> maq=new ArrayList <>();   
            for(int i=0;i<mealyMaq.size();i++)
            {
                wordSeq=mealyMaq.get(i).split(" ");
                SexExp word= new SexExp();
                String newWord="";

                for(int l=0;l<wordSeq.length;l++)
                { 
                    newWord=word.getWord(wordSeq[l]);
                    maq.add(newWord);
                }  
            }
            for(int i=0;i<maq.size();i++){
                String tok=maq.get(i);  
                if(tok.equals("symbols-in"))
                {
                    si=i;
                }
                if(tok.equals("symbols-out"))
                {
                    so=i;
                }
                if(tok.equals("states"))
                {
                    st=i;
                }
                if(tok.equals("start"))
                {
                    sta=i;
                }
                if(tok.equals("finals"))
                {
                    sf=i;
                }
                if(tok.equals("trans"))
                {
                    tr=i;
                }     
            }
            for(int i=si+1;i<so;i++)
            {
                this.inputSymbolsMly.add(maq.get(i));
            }
            for(int i=so+1;i<st;i++)
            {
                this.outputSymbolsMly.add(maq.get(i));
            }
            for(int i=st+1;i<sta;i++)
            {
                this.statesSetMly.add(maq.get(i));
            }    
            for(int i=sta+1;i<sf;i++)
            {
                this.startMly=maq.get(i);
            }
            for(int i=sf+1;i<tr;i++)
            {
                this.finalMly.add(maq.get(i));
            }
            for(int i=tr+1;i<maq.size();i=i+4)
            { 
                ArrayList <String> transSet = new ArrayList<>();
                
                transSet.add(maq.get(i));
                transSet.add(maq.get(i+1));
                transSet.add(maq.get(i+2));
                transSet.add(maq.get(i+3));
                this.transSetMly.add(transSet);
            }        
            System.out.println("\n*** Mealy Machine created from file. ***\n");
    }

    public List<String> getInputSymbolsMly() {
        return inputSymbolsMly;
    }

    public void setInputSymbolsMly(List<String> inputSymbolsMly) {
        this.inputSymbolsMly = inputSymbolsMly;
    }

    public List<String> getOutputSymbolsMly() {
        return outputSymbolsMly;
    }

    public void setOutputSymbolsMly(List<String> outputSymbolsMly) {
        this.outputSymbolsMly = outputSymbolsMly;
    }

    public List<String> getStatesSetMly() {
        return statesSetMly;
    }

    public void setStatesSetMly(List<String> statesSetMly) {
        this.statesSetMly = statesSetMly;
    }

    public String getStartMly() {
        return startMly;
    }

    public void setStartMly(String startMly) {
        this.startMly = startMly;
    }

    public List<String> getFinalMly() {
        return finalMly;
    }

    public void setFinalMly(List<String> finalMly) {
        this.finalMly = finalMly;
    }

    public List <ArrayList<String>> getTransSetMly() {
        return transSetMly;
    }

    public void setTransSetMly(List<ArrayList<String>> transSetMly) {
        this.transSetMly = transSetMly;
    }

    public void ImprimeMealy(){
        System.out.println("Maquina de Mealy: \n");
        System.out.println("Input: \n"+this.getInputSymbolsMly().toString());   
        System.out.println("Output: \n"+this.getOutputSymbolsMly().toString());
        System.out.println("States: \n"+this.getStatesSetMly().toString());
        System.out.println("Start: \n"+this.getStartMly());
        System.out.println("Finals: \n"+this.getFinalMly().toString());
        System.out.println("Trans: \n" +this.getTransSetMly().toString());
        /*List <ArrayList <String>> trans=this.getTransSetMly();
        for(ArrayList <String> item:trans)
        {
            System.out.printf("[");
            int i=0;
            for(i=0;i<item.size()-1;i++)
            {
                System.out.printf(item.get(i)+",");
            }
            System.out.println(item.get(i)+"]");
        }*/  
    }
    public Moore converteMealyToMoore()
    {
        Moore novaMoore=new Moore();
        List <String> entradaMoore=new ArrayList<>();
        List <String> saidaMoore=new ArrayList<>();
        List <String> estadoMoore=new ArrayList<>();
        String startMoore=this.startMly;
        List <String> finalsMoore=new ArrayList<>();
        List<ArrayList<String>> transMoore=new ArrayList<>();
        List<ArrayList<String>> out_fnMoore=new ArrayList<>();
        
        for(String expEnt:this.inputSymbolsMly)
        {
            entradaMoore.add(expEnt);
        }
        for(String expS:this.outputSymbolsMly)
        {
            saidaMoore.add(expS);
        }
        
        ArrayList<String> start_fn=new ArrayList<>();
        start_fn.add(startMoore);
        start_fn.add("()");
        out_fnMoore.add(start_fn);
        for (String estado:this.statesSetMly)
        {
            
            int cont=0;
            List <String> saidaEstado=new ArrayList <>();
            if(!(estadoMoore.contains(estado)))
            {
                estadoMoore.add(estado);
            }
            if(this.finalMly.contains(estado)&& !finalsMoore.contains(estado))
            {
                finalsMoore.add(estado);
            }
            for(ArrayList <String> transMly:this.transSetMly)
            {
                ArrayList <String> novaTrans=new ArrayList<>();
                
                if(estado.equals(transMly.get(1)))
                {
                    String saida=transMly.get(3);
                    
                    
                    if(!saidaEstado.contains(saida))
                    {
                        saidaEstado.add(saida);
                     
                        cont+=1;
                        if(cont>1)
                        {
                            for(int i=0;i<cont-1;i++)
                            {
                                String novoEstado=estado+"'";
                                if(!estadoMoore.contains(novoEstado))
                                {
                                    estadoMoore.add(novoEstado);
                                }
                                if(this.finalMly.contains(estado)&& !finalsMoore.contains(novoEstado))
                                {
                                    finalsMoore.add(novoEstado);
                                }
                                ArrayList<String> novo_fn=new ArrayList<>();
                                novo_fn.add(novoEstado);
                                novo_fn.add(saida);
                                out_fnMoore.add(novo_fn);
                                novaTrans.add(transMly.get(0));
                                novaTrans.add(novoEstado);
                                novaTrans.add(transMly.get(2));
                                transMoore.add(novaTrans);
                            }
                            
                            
                        }
                        else
                        {
                            ArrayList<String> novo_fn=new ArrayList<>();
                            novo_fn.add(estado);
                            novo_fn.add(saida);
                            out_fnMoore.add(novo_fn);
                            novaTrans.add(transMly.get(0));
                            novaTrans.add(estado);
                            novaTrans.add(transMly.get(2));
                            transMoore.add(novaTrans);
                        }
                    }
                    
                }
               
                
                
            }
            
        }
       
        novaMoore.setInputSymbolsMre(entradaMoore);
        novaMoore.setOutputSymbolsMre(saidaMoore);
        novaMoore.setStartMre(startMoore);
        novaMoore.setStatesSetMre(estadoMoore);
        novaMoore.setFinalMre(finalsMoore);
        novaMoore.setTransMre(transMoore);
        novaMoore.setOut_fn(out_fnMoore);
        System.out.println("\n***Moore Machine Convertida***\n");
        return novaMoore;
    }

    void GravaSaidaMealy(String arquivo) 
    {
        try {
            FileWriter out = new FileWriter(new File(arquivo));
            
            String maqSaida= "(mealy\n";
            out.write(maqSaida);
            
            String input="(symbols-in ";
            int i=0;
            for(i=0; i<this.inputSymbolsMly.size()-1;i++)
            {
                input=input+this.inputSymbolsMly.get(i)+" ";
            }
            input=input+this.inputSymbolsMly.get(i)+")\n";
            out.write(input);
            
            String output="(symbols-out ";
            for(i=0; i<this.outputSymbolsMly.size()-1;i++)
            {
                output=output+this.outputSymbolsMly.get(i)+" ";
            }
            output=output+this.outputSymbolsMly.get(i)+")\n";
            out.write(output);
            
            String estado="(states ";
            for(i=0; i<this.statesSetMly.size()-1;i++)
            {
                estado=estado+this.statesSetMly.get(i)+" ";
            }
            estado=estado+this.statesSetMly.get(i)+")\n";
            out.write(estado);
            
            String inicio="(start "+this.startMly+")\n";
            out.write(inicio);
            
            String finals="(finals ";
            for(i=0; i<this.finalMly.size()-1;i++)
            {
                finals=finals+this.finalMly.get(i)+" ";
            }
            finals=finals+this.finalMly.get(i)+")\n";
            out.write(finals);
            out.write("(trans\n");
            
            
            for(ArrayList<String> trans:this.transSetMly)
            {
                String transM="(";
                int t=0;
                for(t=0;t<trans.size();t++){
                    if(t==0)
                    {
                        transM=transM+trans.get(t);
                    }
                    else
                    {
                        transM=transM+" "+trans.get(t);
                    }
                }
 
                transM=transM+")";
                out.write(transM);
            }
            out.write("))");           
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(Mealy.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
    
    
    
   

   


    
   
    

