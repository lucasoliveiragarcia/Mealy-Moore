/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealymoore;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class MealyMoore 
{

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws IOException 
    {
        
        
        // lendo o arquivo de entrada
        FileReader in = new FileReader(new File(args[1]));
        String arquivoSaida=args[3];
        Scanner scanner = new Scanner(in)
                .useDelimiter("\\||\\n");
        List <String> maquina=new ArrayList <>();
        while (scanner.hasNext())
        {
            String leitura= scanner.next();
            maquina.add(leitura);
            
            
        }
        in.close();
       
        
        if(maquina.get(0).contains("mealy"))
        {    
            Mealy mealyMaq=new Mealy(maquina);
            mealyMaq.ImprimeMealy();
            Moore mealyConvertida=new Moore();
            mealyConvertida=mealyMaq.converteMealyToMoore();
            mealyConvertida.ImprimeMoore();
            mealyConvertida.GravaSaidaMoore(arquivoSaida);
        }
        else
        {
            if(maquina.get(0).contains("moore"))
            {
              Moore mooreMaq=new Moore(maquina);
              mooreMaq.ImprimeMoore();
              Mealy mooreConvertida=new Mealy();
              mooreConvertida=mooreMaq.coverteMooreToMealy();
              mooreConvertida.ImprimeMealy();
              mooreConvertida.GravaSaidaMealy(arquivoSaida);
            }
            
        }
        
    }
}
