/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealymoore;


public class SexExp {
   

    public SexExp() {
        
    }
    public String getWord(String wordDel){
        char [] token;
        String word="";
        token=wordDel.toCharArray();
        if(wordDel.contains("("))    
        {
            for(int j=wordDel.indexOf("(")+1;j<wordDel.length();j++)
            {
                if(token[j]!='\n'&& token[j]!='\r' && token[j]!=')')
                {
                    word=word+token[j];
                }
                else 
                {
                    if(token[j]==')'){
                        word="()";
                    }
                    
                }
            }
            return word;
        }
        else if(wordDel.contains(")"))
        {
            for(int k=0;k<wordDel.indexOf(")");k++)
            {                         
                word=word+token[k];
            }
            return word;
        }
        else
        {
            for(int t=0;t<wordDel.length();t++){
                if(token[t]!=' '){
                    word=word+token[t]; 
                }                
            }
            return word;
        }
   
    }
     
    
}
