/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mealymoore;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Moore {
    private List<String> inputSymbolsMre;
    private List<String> outputSymbolsMre;
    private List<String> statesSetMre;
    private String startMre;
    private List<String> finalMre;
    private List<ArrayList<String>> transMre;
    private List<ArrayList<String>> out_fn;

    public Moore() {
    }

    Moore(List<String> mooreMaq) {
        this.inputSymbolsMre=new ArrayList<>();
        this.outputSymbolsMre=new ArrayList<>();
        this.statesSetMre=new ArrayList<>();
        this.startMre="";
        this.finalMre=new ArrayList<>();
        this.transMre=new ArrayList<>();
        this.out_fn=new ArrayList<>();
        String [] wordSeq = null;
        //String [] transSet = new String[4];
        int si=0,so=0,st=0,sta=0,sf=0,tr=0,sfn=0;
        List <String> maq=new ArrayList <>();   
            for(int i=0;i<mooreMaq.size();i++)
            {
                wordSeq=mooreMaq.get(i).split(" ");
                SexExp word= new SexExp();
                String newWord="";

                for(int l=0;l<wordSeq.length;l++)
                { 
                    newWord=word.getWord(wordSeq[l]);
                    maq.add(newWord);
                }  
            }
            for(int i=0;i<maq.size();i++){
                String tok=maq.get(i);  
                if(tok.equals("symbols-in"))
                {
                    si=i;
                }
                if(tok.equals("symbols-out"))
                {
                    so=i;
                }
                if(tok.equals("states"))
                {
                    st=i;
                }
                if(tok.equals("start"))
                {
                    sta=i;
                }
                if(tok.equals("finals"))
                {
                    sf=i;
                }
                if(tok.equals("trans"))
                {
                    tr=i;
                }
                if(tok.equals("out-fn"))
                {
                    sfn=i;
                }
            }
            for(int i=si+1;i<so;i++)
            {
                this.inputSymbolsMre.add(maq.get(i));
            }
            for(int i=so+1;i<st;i++)
            {
                this.outputSymbolsMre.add(maq.get(i));
            }
            for(int i=st+1;i<sta;i++)
            {
                this.statesSetMre.add(maq.get(i));
            }    
            for(int i=sta+1;i<sf;i++)
            {
                this.startMre=maq.get(i);
            }
            for(int i=sf+1;i<tr;i++)
            {
                this.finalMre.add(maq.get(i));
            }
            for(int i=tr+1;i<sfn;i=i+3)
            { 
                ArrayList <String> transSet = new ArrayList<>();
                
                transSet.add(maq.get(i));
                transSet.add(maq.get(i+1));
                transSet.add(maq.get(i+2));
                this.transMre.add(transSet);
            }
            for(int i=sfn+1;i<maq.size();i=i+2)
            { 
                ArrayList <String> fnSet = new ArrayList<>();
                
                fnSet.add(maq.get(i));
                fnSet.add(maq.get(i+1));
                this.out_fn.add(fnSet);
            }
            System.out.println("\n*** Moore Machine created from file. ***\n");
    }

    public List<String> getInputSymbolsMre() {
        return inputSymbolsMre;
    }

    public void setInputSymbolsMre(List<String> inputSymbolsMre) {
        this.inputSymbolsMre = inputSymbolsMre;
    }

    public List<String> getOutputSymbolsMre() {
        return outputSymbolsMre;
    }

    public void setOutputSymbolsMre(List<String> outputSymbolsMre) {
        this.outputSymbolsMre = outputSymbolsMre;
    }

    public List<String> getStatesSetMre() {
        return statesSetMre;
    }

    public void setStatesSetMre(List<String> statesMoore) {
        this.statesSetMre = statesMoore;
    }

    public String getStartMre() {
        return startMre;
    }

    public void setStartMre(String startMre) {
        this.startMre = startMre;
    }

    public List<String> getFinalMre() {
        return finalMre;
    }

    public void setFinalMre(List<String> finalMre) {
        this.finalMre = finalMre;
    }

    public List<ArrayList<String>> getTransMre() {
        return transMre;
    }

    public void setTransMre(List<ArrayList<String>> transMre) {
        this.transMre = transMre;
    }

    

    public List<ArrayList<String>> getOut_fn() {
        return out_fn;
    }

    public void setOut_fn(List<ArrayList<String>> out_fn) {
        this.out_fn = out_fn;
    }

    void ImprimeMoore() {
        System.out.println("\n\nMaquina de Moore: \n");
        System.out.println("Input: \n"+this.inputSymbolsMre.toString());   
        System.out.println("Output: \n"+this.outputSymbolsMre.toString());
        System.out.println("States: \n"+this.statesSetMre);
        System.out.println("Start: \n"+this.startMre);
        System.out.println("Finals: \n"+this.finalMre.toString());
        System.out.println("Trans:" );
        //System.out.println("transMre: "+ transMre.toString());
        List <ArrayList <String>> transM=this.transMre;
        for(ArrayList <String> item:transM)
        {
            System.out.printf("[");
            int i=0;
            for(i=0;i<item.size()-1;i++)
            {
                System.out.printf(item.get(i)+",");
            }
            System.out.println(item.get(i)+"]");
        } 
        System.out.println("out-fn:" );
        List <ArrayList <String>> saida_fn=this.out_fn;
        for(ArrayList <String> item_fn:saida_fn)
        {
            System.out.printf("[");
            int i=0;
            for(i=0;i<item_fn.size()-1;i++)
            {
                System.out.printf(item_fn.get(i)+",");
            }
            System.out.println(item_fn.get(i)+"]");
        }   
    }

    public Mealy coverteMooreToMealy() 
    {
        Mealy novaMealy=new Mealy();
        List <String> entradaMealy=new ArrayList<>();
        List <String> saidaMealy=new ArrayList<>();
        List <String> estadoMealy=new ArrayList<>();
        String startMealy=this.startMre;
        List <String> finalsMealy=new ArrayList<>();
        List<ArrayList<String>> transMealy=new ArrayList<>();
        
        for(String entrada:this.inputSymbolsMre)
        {
            entradaMealy.add(entrada);
        }
        for(String saida:this.outputSymbolsMre)
        {
            saidaMealy.add(saida);
        }
        for(String estado:this.statesSetMre)
        {
            estadoMealy.add(estado);
        }
        for(String finSt:this.finalMre)
        {
            finalsMealy.add(finSt);
        }
        
        for(String estadoMly:estadoMealy){
            
            for(ArrayList<String> transMoo:this.transMre)
            {
                
                if(estadoMly.equals(transMoo.get(0)))
                {
                    ArrayList<String> transMly=new ArrayList<>();
                    transMly.add(transMoo.get(0));
                    transMly.add(transMoo.get(1));
                    transMly.add(transMoo.get(2));
                    for(ArrayList<String> saida_fn:this.out_fn)
                    {
                        if(saida_fn.get(0).equals(transMoo.get(1)) )
                        {
                            transMly.add(saida_fn.get(1));
                        }
                    }    
                    transMealy.add(transMly);
                    
                }    
            }
            
        }
        
        novaMealy.setInputSymbolsMly(entradaMealy);
        novaMealy.setOutputSymbolsMly(saidaMealy);
        novaMealy.setStatesSetMly(estadoMealy);
        novaMealy.setStartMly(startMealy);
        novaMealy.setFinalMly(finalsMealy);
        novaMealy.setTransSetMly(transMealy);
        System.out.println("\n***Mealy Machine Convertida***\n");
       
        return novaMealy;
    }

    void GravaSaidaMoore(String arquivo) 
    {
        try {
            FileWriter out = new FileWriter(new File(arquivo));
            
            String maqSaida= "(moore\n";
            out.write(maqSaida);
            
            String input="(symbols-in ";
            int i=0;
            for(i=0; i<this.inputSymbolsMre.size()-1;i++)
            {
                input=input+this.inputSymbolsMre.get(i)+" ";
            }
            input=input+this.inputSymbolsMre.get(i)+")\n";
            out.write(input);
            
            String output="(symbols-out ";
            for(i=0; i<this.outputSymbolsMre.size()-1;i++)
            {
                output=output+this.outputSymbolsMre.get(i)+" ";
            }
            output=output+this.outputSymbolsMre.get(i)+")\n";
            out.write(output);
            
            String estado="(states ";
            for(i=0; i<this.statesSetMre.size()-1;i++)
            {
                estado=estado+this.statesSetMre.get(i)+" ";
            }
            estado=estado+this.statesSetMre.get(i)+")\n";
            out.write(estado);
            
            String inicio="(start "+this.startMre+")\n";
            out.write(inicio);
            
            String finals="(finals ";
            for(i=0; i<this.finalMre.size()-1;i++)
            {
                finals=finals+this.finalMre.get(i)+" ";
            }
            finals=finals+this.finalMre.get(i)+")\n";
            out.write(finals);
            out.write("(trans\n");
            
            
            for(ArrayList<String> trans:this.transMre)
            {
                String transM="(";
                int t=0;
                for(t=0;t<trans.size();t++){
                    if(t==0)
                    {
                        transM=transM+trans.get(t);
                    }
                    else
                    {
                        transM=transM+" "+trans.get(t);
                    }
                }
 
                transM=transM+")";
                out.write(transM);
            }
            out.write(")\n");
            out.write("(out-fn\n");
            for(ArrayList<String> saida_fn:this.out_fn)
            {
                String fnComp="(";
                int t=0;
                for(t=0;t<saida_fn.size();t++)
                {
                    if(t==0)
                    {
                        fnComp=fnComp+saida_fn.get(t);
                    }
                    else
                    {
                        fnComp=fnComp+" "+saida_fn.get(t);
                    }
                }
                
                if(this.out_fn.indexOf(saida_fn)==this.out_fn.size()-1)
                {
                    fnComp=fnComp+")";
                }
                else
                {
                    fnComp=fnComp+")\n";
                }
                out.write(fnComp);
                
            }
            
            out.write("))");
            out.close();
        } catch (IOException ex) {
            Logger.getLogger(Moore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
